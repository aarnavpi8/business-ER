"""End-to-end starter pipeline: text TF-IDF -> LightGBM CV -> submission.csv

This is the fastest path to a valid leaderboard submission. Once the real
problem statement lands, edit the CONFIG block below (column names, target,
task_type) — everything downstream should keep working.
"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from src.data.loader import load_train, load_test, make_submission
from src.features.text_features import tfidf_features
from src.models.baseline import cv_train, predict_ensemble
from src.utils.metrics import mape_score

# ---- CONFIG: edit once the actual dataset/columns are known ----
TEXT_COL = "catalog_content"
ID_COL = "PRODUCT_ID"
TARGET_COL = "PRICE"
TASK_TYPE = "regression"  # or "classification"
# ------------------------------------------------------------------


def main():
    train = load_train()
    test = load_test()

    X_train_text, X_test_text, _ = tfidf_features(train[TEXT_COL], test[TEXT_COL])
    y = train[TARGET_COL].values

    oof, models = cv_train(X_train_text, y, task_type=TASK_TYPE)

    if TASK_TYPE == "regression":
        print(f"OOF score: {mape_score(y, oof):.4f}")

    test_preds = predict_ensemble(models, X_test_text)
    out = make_submission(test[ID_COL], test_preds, ID_COL, TARGET_COL, "submissions/baseline.csv")
    print(f"wrote {out}")


if __name__ == "__main__":
    main()
