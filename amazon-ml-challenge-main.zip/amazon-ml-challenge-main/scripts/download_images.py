"""Parallel-download product images from a URL column to data/raw/images/.

Usage:
    python scripts/download_images.py --csv data/raw/train.csv --url-col image_link --id-col PRODUCT_ID
"""
import argparse
import sys
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path

import pandas as pd
import requests
from tqdm import tqdm

ROOT = Path(__file__).resolve().parents[1]


def download_one(url: str, out_path: Path, timeout=10, retries=2):
    if out_path.exists():
        return True
    for attempt in range(retries + 1):
        try:
            r = requests.get(url, timeout=timeout)
            r.raise_for_status()
            out_path.write_bytes(r.content)
            return True
        except Exception:
            if attempt == retries:
                return False
    return False


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--csv", required=True)
    ap.add_argument("--url-col", default="image_link")
    ap.add_argument("--id-col", default="PRODUCT_ID")
    ap.add_argument("--out-dir", default=str(ROOT / "data" / "raw" / "images"))
    ap.add_argument("--workers", type=int, default=16)
    args = ap.parse_args()

    out_dir = Path(args.out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    df = pd.read_csv(args.csv)
    if args.url_col not in df.columns:
        sys.exit(f"column '{args.url_col}' not found in {args.csv}; columns are: {list(df.columns)}")

    jobs = []
    with ThreadPoolExecutor(max_workers=args.workers) as ex:
        for _, row in df.iterrows():
            url = row[args.url_col]
            if pd.isna(url):
                continue
            ext = Path(str(url)).suffix or ".jpg"
            out_path = out_dir / f"{row[args.id_col]}{ext}"
            jobs.append(ex.submit(download_one, url, out_path))

        ok = 0
        for f in tqdm(as_completed(jobs), total=len(jobs), desc="downloading"):
            ok += bool(f.result())

    print(f"done: {ok}/{len(jobs)} images saved to {out_dir}")


if __name__ == "__main__":
    main()
