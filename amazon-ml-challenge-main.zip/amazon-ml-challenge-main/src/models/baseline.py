"""Fast baselines to get a leaderboard submission out in the first hour.
Swap task_type + the estimator once you know this year's actual target.
"""
import numpy as np
from sklearn.model_selection import KFold, StratifiedKFold


def cv_train(X, y, task_type="regression", n_splits=5, seed=42, cat_features=None):
    """K-fold train, returns (oof_predictions, list_of_fitted_models)."""
    oof = np.zeros(len(y))
    models = []

    if task_type == "regression":
        import lightgbm as lgb

        kf = KFold(n_splits=n_splits, shuffle=True, random_state=seed)
        splitter = kf.split(X)
        params = dict(objective="regression", metric="mape", n_estimators=2000,
                      learning_rate=0.03, num_leaves=63, random_state=seed)
    else:
        import lightgbm as lgb

        kf = StratifiedKFold(n_splits=n_splits, shuffle=True, random_state=seed)
        splitter = kf.split(X, y)
        params = dict(objective="multiclass" if len(np.unique(y)) > 2 else "binary",
                      n_estimators=2000, learning_rate=0.03, num_leaves=63, random_state=seed)
        if len(np.unique(y)) > 2:
            params["num_class"] = len(np.unique(y))

    for fold, (tr_idx, val_idx) in enumerate(splitter):
        X_tr, X_val = X[tr_idx], X[val_idx]
        y_tr, y_val = y[tr_idx], y[val_idx]

        model = lgb.LGBMRegressor(**params) if task_type == "regression" else lgb.LGBMClassifier(**params)
        model.fit(
            X_tr, y_tr,
            eval_set=[(X_val, y_val)],
            callbacks=[lgb.early_stopping(100, verbose=False)],
        )
        pred = model.predict(X_val)
        oof[val_idx] = pred
        models.append(model)
        print(f"fold {fold}: done ({len(val_idx)} val rows)")

    return oof, models


def predict_ensemble(models, X):
    preds = np.stack([m.predict(X) for m in models], axis=0)
    return preds.mean(axis=0)
