"""Simple weighted-average / stacking ensembling across model families
(LightGBM + XGBoost + CatBoost is the usual winning combo in these contests).
"""
import numpy as np
from scipy.optimize import minimize


def weighted_average(preds_list, weights=None):
    preds = np.stack(preds_list, axis=0)
    if weights is None:
        weights = np.ones(len(preds_list)) / len(preds_list)
    weights = np.asarray(weights)
    return (preds * weights[:, None]).sum(axis=0)


def fit_optimal_weights(oof_preds_list, y_true, loss_fn):
    """Find non-negative weights (summing to 1) minimizing loss_fn(y_true, blend)."""
    n = len(oof_preds_list)
    oof = np.stack(oof_preds_list, axis=0)

    def objective(w):
        w = np.abs(w)
        w = w / w.sum()
        blend = (oof * w[:, None]).sum(axis=0)
        return loss_fn(y_true, blend)

    x0 = np.ones(n) / n
    res = minimize(objective, x0, method="Nelder-Mead")
    w = np.abs(res.x)
    return w / w.sum()
