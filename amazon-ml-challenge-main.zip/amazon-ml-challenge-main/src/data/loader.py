"""Load competition CSVs. Adjust column names once the real files land —
these are the column names actually used in the 2023/2025 editions."""
from pathlib import Path
import pandas as pd

DATA_DIR = Path(__file__).resolve().parents[2] / "data" / "raw"


def load_train(filename: str = "train.csv") -> pd.DataFrame:
    return pd.read_csv(DATA_DIR / filename)


def load_test(filename: str = "test.csv") -> pd.DataFrame:
    return pd.read_csv(DATA_DIR / filename)


def make_submission(ids, predictions, id_col: str, target_col: str, out_path: str):
    """Write a CSV in the id_col/target_col shape the platform expects."""
    df = pd.DataFrame({id_col: ids, target_col: predictions})
    df.to_csv(out_path, index=False)
    return out_path
