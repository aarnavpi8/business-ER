"""OCR fallback for image-embedded entity extraction (2024-style: weight,
dimensions, volume printed on packaging). Try easyocr first — no external
binary needed. pytesseract needs the Tesseract binary installed separately
(https://github.com/UB-Mannheim/tesseract/wiki on Windows) and on PATH.
"""
_READER_CACHE = {}


def easyocr_read(image_path, langs=("en",), gpu=False):
    import easyocr

    key = (langs, gpu)
    if key not in _READER_CACHE:
        _READER_CACHE[key] = easyocr.Reader(list(langs), gpu=gpu)
    reader = _READER_CACHE[key]
    results = reader.readtext(str(image_path))
    return [text for (_bbox, text, _conf) in results]


def tesseract_read(image_path):
    import pytesseract
    from PIL import Image

    return pytesseract.image_to_string(Image.open(image_path))
