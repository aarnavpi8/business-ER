"""Image feature extraction from product photos.

embed_images() uses a frozen CLIP vision encoder — strong generic baseline
for both regression (price/length) and classification (browse node) tasks.
Requires: pip install -r requirements-heavy.txt
"""
from pathlib import Path
import numpy as np
from PIL import Image

_MODEL_CACHE = {}


def embed_images(image_paths, model_name="ViT-B-32", pretrained="openai", batch_size=32, device=None):
    import torch
    import open_clip

    key = (model_name, pretrained)
    if key not in _MODEL_CACHE:
        model, _, preprocess = open_clip.create_model_and_transforms(model_name, pretrained=pretrained)
        model.eval()
        if device:
            model = model.to(device)
        _MODEL_CACHE[key] = (model, preprocess)
    model, preprocess = _MODEL_CACHE[key]

    feats = []
    batch = []

    def flush():
        if not batch:
            return
        with torch.no_grad():
            x = torch.stack(batch)
            if device:
                x = x.to(device)
            out = model.encode_image(x).cpu().numpy()
            feats.append(out)
        batch.clear()

    for p in image_paths:
        try:
            img = Image.open(p).convert("RGB")
            batch.append(preprocess(img))
        except Exception:
            batch.append(preprocess(Image.new("RGB", (224, 224))))
        if len(batch) == batch_size:
            flush()
    flush()
    return np.concatenate(feats, axis=0) if feats else np.empty((0, 512))
