"""Text feature extraction for catalog_content / title+description+bullets.

Two paths:
- tfidf_features(): fast, dependency-light, good first baseline.
- embed_texts(): sentence-transformers embeddings, needs requirements-heavy.txt.
"""
from sklearn.feature_extraction.text import TfidfVectorizer


def tfidf_features(train_texts, test_texts=None, max_features=20000, ngram_range=(1, 2)):
    vec = TfidfVectorizer(max_features=max_features, ngram_range=ngram_range, sublinear_tf=True)
    X_train = vec.fit_transform(train_texts)
    X_test = vec.transform(test_texts) if test_texts is not None else None
    return X_train, X_test, vec


_MODEL_CACHE = {}


def embed_texts(texts, model_name="sentence-transformers/all-MiniLM-L6-v2", batch_size=64, device=None):
    """Dense sentence embeddings. Requires: pip install -r requirements-heavy.txt"""
    from sentence_transformers import SentenceTransformer

    if model_name not in _MODEL_CACHE:
        _MODEL_CACHE[model_name] = SentenceTransformer(model_name, device=device)
    model = _MODEL_CACHE[model_name]
    return model.encode(
        list(texts), batch_size=batch_size, show_progress_bar=True, convert_to_numpy=True
    )
