"""Scoring functions matching past Amazon ML Challenge evaluation metrics.

Swap in whichever one matches the current year's problem statement once
it's released — keep the others around since the task type varies by year.
"""
import numpy as np
from sklearn.metrics import mean_absolute_percentage_error


def mape_score(y_true, y_pred):
    """2023-style score: max(0, 100 * (1 - MAPE))."""
    y_true, y_pred = np.asarray(y_true), np.asarray(y_pred)
    mape = mean_absolute_percentage_error(y_true, y_pred)
    return max(0.0, 100.0 * (1.0 - mape))


def smape(y_true, y_pred):
    """Symmetric MAPE — common alternative for price/length regression."""
    y_true, y_pred = np.asarray(y_true, dtype=float), np.asarray(y_pred, dtype=float)
    denom = (np.abs(y_true) + np.abs(y_pred)) / 2.0
    denom = np.where(denom == 0, 1e-9, denom)
    return np.mean(np.abs(y_true - y_pred) / denom) * 100.0


def subset_accuracy(y_true, y_pred):
    """2021-style score for multiclass/multilabel: exact match rate."""
    y_true, y_pred = np.asarray(y_true), np.asarray(y_pred)
    return float(np.mean(y_true == y_pred))


def f1_micro(y_true, y_pred):
    from sklearn.metrics import f1_score
    return f1_score(y_true, y_pred, average="micro")
