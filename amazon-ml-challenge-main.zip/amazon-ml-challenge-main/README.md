# Amazon ML Challenge 2026 — prep repo

Starter kit built ahead of the problem statement drop, based on patterns from
past editions.

## Past editions (for context)

| Year | Task | Metric |
|---|---|---|
| 2021 | Browse node classification (text -> ~9,919 classes) | subset accuracy |
| 2023 | Product length regression (tabular) | `max(0, 100*(1-MAPE))` |
| 2024 | Entity extraction from product images (OCR/VLM) | — |
| 2025 | Price prediction from catalog text + product image (multimodal) | — |

Trend: moving from single-modality (text-only / tabular) toward **multimodal
text+image** problems. This repo is set up to handle either.

## Structure

```
data/raw/            # competition CSVs + downloaded images (gitignored)
data/processed/       # cached features (gitignored)
src/data/loader.py    # CSV I/O, submission writer
src/features/         # text_features.py (TF-IDF, sentence-transformers)
                       # image_features.py (CLIP embeddings)
src/ocr/extract.py    # easyocr / pytesseract wrappers
src/models/           # baseline.py (LightGBM CV), ensemble.py (blending)
src/utils/metrics.py  # scoring fns matching each past year's metric
scripts/
  download_images.py  # pull product images from an image_link column
  run_baseline.py      # end-to-end: text -> LightGBM -> submission.csv
submissions/           # generated CSVs (gitignored)
```

## Setup

```powershell
cd amazon-ml-challenge
python -m venv .venv
.venv\Scripts\activate
pip install -r requirements.txt

# only once you know the task needs embeddings/CLIP/OCR (multi-GB downloads):
pip install -r requirements-heavy.txt
```

## Day-of workflow

1. Drop `train.csv` / `test.csv` into `data/raw/`.
2. If there's an image URL column: `python scripts/download_images.py --csv data/raw/train.csv --url-col <col> --id-col <col>`
3. Edit the `CONFIG` block at the top of `scripts/run_baseline.py` (column
   names, target, task type) to match the real problem statement.
4. `python scripts/run_baseline.py` — get *a* submission on the board first,
   then iterate: swap TF-IDF for sentence-transformer embeddings, add CLIP
   image features, blend LightGBM/XGBoost/CatBoost via `src/models/ensemble.py`.
